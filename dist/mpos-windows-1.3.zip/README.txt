﻿MPOS Windows Release (Argit)
============================

Install
-------
1. Extract this entire folder (keep all files next to mpos.exe).
2. Run mpos.exe.

If Windows SmartScreen / "Unknown publisher" appears
----------------------------------------------------
1. Click More info -> Run anyway (only if you received this from Argit).
2. Or (internal PCs): install Argit-MPOS-CodeSigning.cer into
   Trusted Root Certification Authorities / Trusted Publishers,
   then re-open mpos.exe.

If Chrome says "Virus detected" on download
-------------------------------------------
This is a common false positive for unsigned/self-signed desktop apps.
Prefer sharing via Google Drive / OneDrive company link, or ask IT to
allowlist the file. A commercial code-signing certificate (OV/EV) is
required to clear browser Safe Browsing fully.
